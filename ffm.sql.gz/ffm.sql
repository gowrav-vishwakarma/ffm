-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 06, 2012 at 03:22 PM
-- Server version: 5.5.24
-- PHP Version: 5.3.10-1ubuntu3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ffm`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxcategory`
--

CREATE TABLE IF NOT EXISTS `jos_xxcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxgroups`
--

CREATE TABLE IF NOT EXISTS `jos_xxgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `head_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `Path` text,
  `pos_id` int(11) DEFAULT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_jos_xxgroups_jos_xxpos1` (`pos_id`),
  KEY `fk_jos_xxgroups_jos_xxheads1` (`head_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `jos_xxgroups`
--

INSERT INTO `jos_xxgroups` (`id`, `name`, `head_id`, `group_id`, `Path`, `pos_id`, `lft`, `rgt`) VALUES
(1, 'root', NULL, NULL, '0', NULL, 0, 55),
(2, 'Capital Account', 1, NULL, NULL, NULL, 1, 2),
(3, 'Bank OD', 2, NULL, NULL, NULL, 3, 4),
(4, 'Bank CC', 2, NULL, NULL, NULL, 5, 6),
(5, 'Bank Loan', 1, NULL, NULL, NULL, 7, 8),
(6, 'Secured Loan', 1, NULL, NULL, NULL, 9, 10),
(7, 'Un Secured Loan', 2, NULL, NULL, NULL, 11, 12),
(8, 'Sundry Creditors', 3, NULL, NULL, NULL, 15, 16),
(9, 'Duties And Taxes', 3, NULL, NULL, NULL, 17, 18),
(10, 'Provisions', 3, NULL, NULL, NULL, 19, 20),
(11, 'Suspance', 4, NULL, NULL, NULL, 21, 22),
(13, 'Branches And Divisions', 5, NULL, NULL, NULL, 25, 26),
(14, 'Fixed Assets', 6, NULL, NULL, NULL, 27, 28),
(15, 'Investments', 7, NULL, NULL, NULL, 29, 30),
(16, 'Closing Stocks', 8, NULL, NULL, NULL, 31, 32),
(17, 'Current Assets', 8, NULL, NULL, NULL, 33, 34),
(19, 'Loan And Avances (Assets)', 8, NULL, NULL, NULL, 37, 38),
(20, 'Sundry Debtors', 8, NULL, NULL, NULL, 39, 40),
(21, 'Bank Accounts', 8, NULL, NULL, NULL, 41, 42),
(22, 'Direct Expenses', 10, NULL, NULL, NULL, 43, 44),
(23, 'In Direct Expenses', 11, NULL, NULL, NULL, 45, 46),
(24, 'Direct Income', 12, NULL, NULL, NULL, 47, 48),
(25, 'In Direct income', 13, NULL, NULL, NULL, 49, 50),
(26, 'Purchase Account', 14, NULL, NULL, NULL, 51, 52),
(27, 'Sales Account', 15, NULL, NULL, NULL, 53, 54);

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxheads`
--

CREATE TABLE IF NOT EXISTS `jos_xxheads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `isPANDL` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `jos_xxheads`
--

INSERT INTO `jos_xxheads` (`id`, `name`, `type`, `isPANDL`) VALUES
(1, 'Capital Account', 'Liability', 0),
(2, 'Loans (Liability)', 'Liability', 0),
(3, 'Current Liabilities', 'Liability', 0),
(4, 'Suspance Account', 'Liability', 0),
(5, 'Branch And Division', 'Liability', 0),
(6, 'Fixed Assets', 'Asset', 0),
(7, 'Investements', 'Asset', 0),
(8, 'Current Assets', 'Asset', 0),
(10, 'Direct Expenses', 'P&L', 1),
(11, 'InDirect Expenses', 'P&L', 1),
(12, 'Direct Income', 'P&L', 1),
(13, 'InDirect Income', 'P&L', 1),
(14, 'Purchase Account', 'P&L', 1),
(15, 'Sales Account', 'P&L', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxitems`
--

CREATE TABLE IF NOT EXISTS `jos_xxitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `LastPurchasePrice` float DEFAULT NULL,
  `DP` float DEFAULT NULL,
  `MRP` float DEFAULT NULL,
  `DealerPrice` float DEFAULT NULL,
  `RetailerPrice` float DEFAULT NULL,
  `Unit` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_jos_xxitems_jos_xxcategory1` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxledgers`
--

CREATE TABLE IF NOT EXISTS `jos_xxledgers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `OpBalCR` float DEFAULT NULL,
  `OpBalDR` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `distributor_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `pos_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_jos_xxledgers_jos_xxgroups1` (`group_id`),
  KEY `fk_jos_xxledgers_jos_xxpos1` (`pos_id`),
  KEY `fk_jos_xxledgers_jos_xxstaff1` (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_xxledgers`
--

INSERT INTO `jos_xxledgers` (`id`, `name`, `OpBalCR`, `OpBalDR`, `created_at`, `updated_at`, `distributor_id`, `group_id`, `pos_id`, `staff_id`) VALUES
(1, 'pos_1', NULL, 0, '2012-09-06 00:00:00', '2012-09-06 00:00:00', 1, NULL, NULL, NULL),
(2, 'pos_2', NULL, 0, '2012-09-06 00:00:00', '2012-09-06 00:00:00', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxparties`
--

CREATE TABLE IF NOT EXISTS `jos_xxparties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `MobileNumber` varchar(30) DEFAULT NULL,
  `pos_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`pos_id`),
  KEY `fk_jos_xxparties_jos_xxpos1` (`pos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxpos`
--

CREATE TABLE IF NOT EXISTS `jos_xxpos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_xxpos`
--

INSERT INTO `jos_xxpos` (`id`, `name`, `owner_id`, `type`) VALUES
(1, 'COMPANY POS', 1, 'Company'),
(2, 'pos_2', 1, 'Depot');

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxstaff`
--

CREATE TABLE IF NOT EXISTS `jos_xxstaff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `pos_id` int(11) DEFAULT NULL,
  `AccessLevel` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_jos_xxstaff_jos_xxpos` (`pos_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_xxstaff`
--

INSERT INTO `jos_xxstaff` (`id`, `name`, `username`, `password`, `pos_id`, `AccessLevel`) VALUES
(1, 'COMPANY POS_SUPER_STAFF', 'pos_1_admin', 'admin', 1, '1000'),
(2, 'pos_2_SUPER_STAFF', 'pos_2_admin', 'admin', 2, '100');

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxstocks`
--

CREATE TABLE IF NOT EXISTS `jos_xxstocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Stock` int(11) DEFAULT NULL,
  `pos_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxvoucherdetails`
--

CREATE TABLE IF NOT EXISTS `jos_xxvoucherdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `Rate` float DEFAULT '0',
  `Qty` float DEFAULT '0',
  `Amount` float DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_jos_xxvoucherdetails_jos_xxvouchers1` (`voucher_id`),
  KEY `fk_jos_xxvoucherdetails_jos_xxitems1` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_xxvouchers`
--

CREATE TABLE IF NOT EXISTS `jos_xxvouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ledger_id` int(11) DEFAULT NULL,
  `AmountCR` float DEFAULT NULL,
  `AmountDR` float DEFAULT NULL,
  `VoucherNo` int(11) DEFAULT NULL,
  `Narration` varchar(255) DEFAULT NULL,
  `VoucherType` varchar(50) DEFAULT NULL,
  `RefAccount` int(11) DEFAULT NULL,
  `pos_id` int(11) DEFAULT NULL,
  `has_details` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_jos_xxvouchers_jos_xxledgers1` (`ledger_id`),
  KEY `fk_jos_xxvouchers_jos_xxpos1` (`pos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jos_xxgroups`
--
ALTER TABLE `jos_xxgroups`
  ADD CONSTRAINT `fk_jos_xxgroups_jos_xxheads1` FOREIGN KEY (`head_id`) REFERENCES `jos_xxheads` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jos_xxgroups_jos_xxpos1` FOREIGN KEY (`pos_id`) REFERENCES `jos_xxpos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `jos_xxitems`
--
ALTER TABLE `jos_xxitems`
  ADD CONSTRAINT `fk_jos_xxitems_jos_xxcategory1` FOREIGN KEY (`category_id`) REFERENCES `jos_xxcategory` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `jos_xxledgers`
--
ALTER TABLE `jos_xxledgers`
  ADD CONSTRAINT `fk_jos_xxledgers_jos_xxgroups1` FOREIGN KEY (`group_id`) REFERENCES `jos_xxgroups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jos_xxledgers_jos_xxpos1` FOREIGN KEY (`pos_id`) REFERENCES `jos_xxpos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jos_xxledgers_jos_xxstaff1` FOREIGN KEY (`staff_id`) REFERENCES `jos_xxstaff` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `jos_xxparties`
--
ALTER TABLE `jos_xxparties`
  ADD CONSTRAINT `fk_jos_xxparties_jos_xxpos1` FOREIGN KEY (`pos_id`) REFERENCES `jos_xxpos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `jos_xxstaff`
--
ALTER TABLE `jos_xxstaff`
  ADD CONSTRAINT `fk_jos_xxstaff_jos_xxpos` FOREIGN KEY (`pos_id`) REFERENCES `jos_xxpos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `jos_xxvoucherdetails`
--
ALTER TABLE `jos_xxvoucherdetails`
  ADD CONSTRAINT `fk_jos_xxvoucherdetails_jos_xxitems1` FOREIGN KEY (`item_id`) REFERENCES `jos_xxitems` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jos_xxvoucherdetails_jos_xxvouchers1` FOREIGN KEY (`voucher_id`) REFERENCES `jos_xxvouchers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `jos_xxvouchers`
--
ALTER TABLE `jos_xxvouchers`
  ADD CONSTRAINT `fk_jos_xxvouchers_jos_xxledgers1` FOREIGN KEY (`ledger_id`) REFERENCES `jos_xxledgers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_jos_xxvouchers_jos_xxpos1` FOREIGN KEY (`pos_id`) REFERENCES `jos_xxpos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
