<?php
/*------------------------------------------------------------------------
# com_xcideveloper - Seamless merging of CI Development Style with Joomla CMS
# ------------------------------------------------------------------------
# author    Xavoc International / Gowrav Vishwakarma
# copyright Copyright (C) 2011 xavoc.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.xavoc.com
# Technical Support:  Forum - http://xavoc.com/index.php?option=com_discussions&view=index&Itemid=157
-------------------------------------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<base href="<?= $this->config->item('base_url') ?>" />
<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//$this->load->helper('ofc');
//$this->jq->useGraph();
////open_flash_chart_object( 300, 200, "index.php?option=com_mlm&format=raw&task=ofc2.get_data_bar", false );
//$data_url="index.php?option=com_mlm&format=raw&task=ofc2.get_data_bar";
//$this->jq->getGraphObject('80%','300',$data_url, 'test_div');
//$data_url="index.php?option=com_mlm&format=raw&task=ofc2.get_data_line";
//$this->jq->getGraphObject('80%','300',$data_url, 'test_div2');
?>
